# MariaDB

## Overview

The MariaDB It wraps the official stable [Mariadb chart](https://github.com/helm/charts/tree/master/stable/mariadb).
Find more information about the Mariadb chart in the chart's [documentation](chart/mariadb/README.md).

## Details

The mariadb addon contains two plans:
- micro
- entrerpise

It is a show case how to define chart values in a plan.
